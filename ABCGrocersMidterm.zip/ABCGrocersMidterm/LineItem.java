package com;

public class LineItem
{
    // declaring variables
    public String itemName;
    public int quantity;
    public double price;

    // constructor
    public LineItem(String itemName, int quantity, double price)
    {
        this.itemName = itemName;
        this.quantity = quantity;
        this.price = price;
    }

    // getter - item name
    public String getItemName()
    {
        return this.itemName;
    }

    // getter - quantity
    public int getQuantity()
    {
        return this.quantity;
    }

    // getter - price
    public double getPrice()
    {
        return price;
    }

    // getter - total price
    public double getTotalPrice()
    {
        double totalPrice;
        totalPrice = this.quantity * this.price;
        return totalPrice;
    }

    // get method - set quantity
    public void setQuantity(int quantity)
    {
        this.quantity = quantity;
    }

    // get method - set price
    public void setPrice(double price)
    {
        this.price = price;
    }

    // toString()
    public String toString()
    {
        String lineItemDescription;
        lineItemDescription = (itemName + "\t\tqty " + quantity + " @ $" + price + "\t\t" + "$" + getTotalPrice());
        return lineItemDescription;
    }
}
