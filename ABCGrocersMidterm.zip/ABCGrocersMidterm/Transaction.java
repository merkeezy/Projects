package com;

import java.text.DecimalFormat;
import java.util.ArrayList;

public class Transaction
{
    // declaring variables
    public ArrayList<LineItem> lineItems;
    public int customerID;
    public String customerName;
    DecimalFormat decimalFormat = new DecimalFormat("#.##");

    // constructor
    public Transaction(int customerID, String customerName)
    {

        this.customerID = customerID;
        this.customerName = customerName;
        lineItems = new ArrayList<LineItem>();
    }

    // adding item
    public void addLineItem(String itemName, int quantity, double price)
    {
        // Create line item object by passing itemName, quantity, price
        LineItem lineItem = new LineItem(itemName, quantity, price);

        // Add lineItem to lineItems
        lineItems.add(lineItem);
    }

    // Method to update line item
    public void updateItem(String itemName, int quantity, double price) {
        LineItem lineItem = null;

        // Find the line item by itemName
        for (int i = 0; i < lineItems.size(); i++) {
            lineItem = lineItems.get(i);
            if (lineItem.getItemName().equalsIgnoreCase(itemName)) {
                lineItem.setQuantity(quantity);
                lineItem.setPrice(price);
                break;
            } else if (i == lineItems.size() - 1)
                System.out.println("\nCannot Find Item. Please Check Item Number and Try Again.");
        }

        // Check if line item found or not, if found update quantity
    }

    // Method to get Total price
    public double getTotalPrice()
    {
        double totalPriceOfLineItems = 0;

        // Iterate over all line items
        for (int i = 0; i < lineItems.size(); i++)
        {
            totalPriceOfLineItems = totalPriceOfLineItems + lineItems.get(i).getTotalPrice();
        }

        return totalPriceOfLineItems;
    }

    // Get Line item by item name
    public String getLineItem(String itemName)
    {

        boolean isFound = false;
        LineItem lineItem = null;

        // Find the line item by itemName
        for (int i = 0; i < lineItems.size(); i++)
        {
            lineItem = lineItems.get(i);
            if (lineItem.getItemName().equalsIgnoreCase(itemName))
            {
                isFound = true;
                break;
            }
        }

        // Check if line item found or not
        if (isFound)
        {
            return lineItem.toString();
        } else
        {
            return "\nCannot Find Item. Please Check Item Number and Try Again.";
        }
    }

    // toString() method to return transaction description
    public String toString()
    {

        String transactionDescription;

        //Get line items description
        String linItemsDescription = "";
        for (int i = 0; i < lineItems.size(); i++)
        {
            linItemsDescription = linItemsDescription + lineItems.get(i).toString() + "\n";
        }

        transactionDescription = "Customer ID : " + customerID + "\nCustomer Name : " + customerName + "\n"
                + linItemsDescription + "Transaction Total : \t\t\t$" + decimalFormat.format(getTotalPrice());

        return transactionDescription;
    }
}
