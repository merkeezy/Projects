package com;

public class RetailTransaction
{
    public static void main(String[] args)
    {

        //transaction object
        Transaction transaction = new Transaction(12345, "John Doe");

        //adding line items
        transaction.addLineItem("Colgate Toothpaste", 2, 2.99);
        transaction.addLineItem("Bounty Paper Towels", 1, 1.49);
        transaction.addLineItem("Kleenex Tissue ",  1, 2.49);

        // toString() method outputting transaction description
        System.out.println(transaction.toString());

        //updating line items
        transaction.updateItem("Colgate Toothpaste", 3, 22.50);

        System.out.println("\n-------- Updated Transaction details ---------");
        System.out.println(transaction.toString());

    }

}

